<?php @session_start();


header ("Content-type: image/png");
$path=$_SESSION['map'][$_GET['y']][$_GET['id']];
//$path='"'.$get.'"';//.$name";
$im=imagecreatefrompng($path);
if(isset($_GET['typeMap'])){
	$image=imagecreatetruecolor(12,12);
	imagecopyresized($image,$im,0,0,0,0,12,12,16,16);
	imagedestroy($im);
	$im=$image;
}
$transp = imagecolorallocate($im, 0, 0, 0);
imagecolortransparent($im, $transp);
imagepng($im);
//imagedestroy($im);


?>
