vue interieur chateau 2

<br><br><br>

<div id="construire">
	Construire un batiment<br>
	<form action="batiment.php" method="post">
		<INPUT type="submit" value="construire" />
	</form>
</div>

<br><br>

<div id="recruter">
	recruter des unites
	<form action="recrutement.php" method="post">
		<INPUT type="submit" value="recruter" />
	</form>
</div>
