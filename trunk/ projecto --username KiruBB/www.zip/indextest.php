<?php	session_start(); 
include 'scripts.js';	
include ("scripts.js");
?>
<HTML>
<HEAD>
<link href="style2.css" rel="stylesheet" type="text/css">  
<TITLE>Design</TITLE>
</HEAD>

<BODY bgcolor=white>
	<div id="pouet" onclick="loadPage('pouet.php','paf')"> </div>
	<div id="paf"></div>
</BODY>
</HTML>