<!--______________________________________________________________________________________________-->
<!-- 						FICHIER A INCLURE DANS INDEX.PHP 									  -->
<!--______________________________________________________________________________________________-->

<div id="contenu" >
	<?php
		include 'ressources.php';
		include 'menu.php';			
		//include 'menuG.php';
		include 'main.php';
		//include 'menuD.php';
	?>
</div>

