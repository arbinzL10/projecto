<?php @session_start();

include 'map.php';
if(isset($_POST['map_joueur'])){
	$x=0;
	$y=0;
	if(isset($_POST['map_joueur'][0])){
		$x=$_POST['map_joueur'][0];
		$y=$_POST['map_joueur'][1];
	}
	//---------------------- � utiliser pour l'affichage ----------------------------------------------//
	$_SESSION['tiles']=getTileset();
	foreach($_SESSION['tiles'] as $key => $value){
		foreach($_SESSION['tiles'][$key] as $key2 => $value2){
			if($key2!=''){
				$_SESSION['tiles'][$_SESSION['tiles'][$key][$key2]['id']]['path']=$_SESSION['tiles'][$key][$key2]['path'];
				//$image=$_SESSION['tiles'][$_SESSION['tiles'][$key][$key2]['id']]['image'];
			}
		}
	}
	$map=getMap($_SESSION['identify']['id'],'mapjoueur',$x,$y);
	$_SESSION['map']=parseMap($_SESSION['tiles'],$map);
	$mapsize=getMapSize();
	//------------------------------------------------------------------------------------------------//
	$i=0;
	$j=0;
	echo "<div id='map'>
			<div id='zoom' onclick=HTTPReq('map_monde',null,'aff_map.php','main')>
				<label>mapmonde</label>
			</div>
			<div id='flecheH' onclick=\"HTTPReq(new Array('map_joueur[0]','map_joueur[1]'),new Array(null,5,0),'aff_map.php','main')\">
				<IMG SRC=images/flecheH.png >
			</div>
			<div id='flecheG' onclick=\"HTTPReq(new Array('map_joueur[0]','map_joueur[1]'),new Array(null,0,5),'aff_map.php','main')\">
				<IMG SRC=images/flecheG.png >
			</div>
		 	<div id='tiles'>";
	if($x==0 and $y==0){
	foreach($_SESSION['map'] as $key => $value){
		foreach($_SESSION['map'][$key] as $key2 => $value2){
			if($mapsize['width']==$i){
				echo '<br />';
				$i=0;
			}
			echo "<IMG SRC=affichage_map.php?y=$key&id=$j >";
			$i++;			
			$j++;
		}
		echo '<br />';
		$j=0;	
	}
	}else{
	foreach($_SESSION['map'] as $key => $value){
		foreach($_SESSION['map'][$key] as $key2 => $value2){
			if($mapsize['width']==$i){
				echo '<br />';
				$i=0;
			}
			echo "<IMG SRC=affichage_map.php?y=$key&id=$j >";
			$i++;			
			$j++;
		}
		echo '<br />';
		$j=0;	
	}
	}
	echo "	</div>
			<div id='flecheD' onclick=\"HTTPReq(new Array('map_joueur[0]','map_joueur[1]'),new Array(null,5,0),'aff_map.php','main')\">
				<IMG SRC=images/flecheD.png >
			</div>
			<div id='flecheB' onclick=\"HTTPReq(new Array('map_joueur[0]','map_joueur[1]'),new Array(null,0,5),'aff_map.php','main')\">
				<IMG SRC=images/flecheB.png >
			</div>
		</div>";
}
if(isset($_POST['map_monde'])){
	$_SESSION['tiles']=getTileset();
	foreach($_SESSION['tiles'] as $key => $value){
		foreach($_SESSION['tiles'][$key] as $key2 => $value2){
			if($key2!=''){
				$_SESSION['tiles'][$_SESSION['tiles'][$key][$key2]['id']]['path']=$_SESSION['tiles'][$key][$key2]['path'];
				//$image=$_SESSION['tiles'][$_SESSION['tiles'][$key][$key2]['id']]['image'];
			}
		}
	}
	$map=getMap($_SESSION['identify']['id'],'mapmonde');
	$_SESSION['map']=parseMap($_SESSION['tiles'],$map);
	$mapsize=getMapSize();
	$width=$mapsize['width']*$map['nb_joueurs'];
	//------------------------------------------------------------------------------------------------//
	$i=0;
	$j=0;
	$k=0;
	echo "<div id='zoom' onclick=HTTPReq('map_joueur',null,'aff_map.php','b_menu')>
			<label>map du royaume</label>
		 </div><br />";
	foreach($_SESSION['map'] as $key => $value){
		foreach($_SESSION['map'][$key] as $key2 => $value2){
			if($width==$k){
				echo '<br />';
				$k=0;
			}
			echo "<IMG SRC=affichage_map.php?y=$key&id=$j&typeMap='mapmonde'>";
			$j++;
			$k++;
		}
		echo '<br />';
		$i=0;
	}
}

?>
