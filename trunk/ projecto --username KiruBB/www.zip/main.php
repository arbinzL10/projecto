<div id='main' onClick="menuEraseAll()" >
		
		<!-- 
		<div id="main"><br><br><br><br>
			fenetre dans laquelle <br><br>apparaitra la map, les messages,<br><br> les batiments d'un chateau, <br><br>les �volutions accessibles ou non.
		</div>
		!-->
</div>
</div>
