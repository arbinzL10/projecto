vue interieur chateau 1

<br><br><br>

<div id="construire">
	<div id="boutonconstruire" onclick="loadPage('batiment.php','main')">construire un batiment</div>
</div>

<br><br>

<div id="recruter">
	recruter des unites
	<form action="caserne.php" method="post">
		<INPUT type="submit" value="recruter" />
	</form>
</div>
